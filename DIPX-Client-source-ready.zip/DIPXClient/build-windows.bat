@echo off
java -version
if errorlevel 1 exit /b 1
gradle --version
if errorlevel 1 exit /b 1
gradle build
if errorlevel 1 exit /b 1
echo.
echo DIPX build output:
dir build\libs\*.jar
