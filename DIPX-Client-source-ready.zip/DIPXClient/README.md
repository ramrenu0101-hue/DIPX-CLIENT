# DIPX Client — Minecraft 1.21.11 (Fabric)

This is the DIPX starter source project recovered from the uploaded ZIP.

## Target setup
- Minecraft Java 1.21.11
- Fabric Loader 0.18.1+
- Fabric API 0.141.4+1.21.11
- Build JDK: Java 21 (recommended)
- GUI key: Right Shift

## Build
Install a JDK 21 and Gradle 8.14.3 or newer compatible with Fabric Loom 1.14, then run from this folder:

```sh
gradle build
```

The remapped mod JAR should be generated under `build/libs/`.

## Current implementation status
Implemented in source: client entrypoint, Right Shift keybind, category-based ClickGUI, clickable module toggles, and enabled-module HUD count.

Not implemented yet: actual crystal/anchor/mace automation, combat automation, ESP/tracers, radar, inventory automation, and other advanced modules. These are registered as placeholders only and are not functional features.

## Important
- This ZIP is source code, **not an installable mod JAR**.
- The build was not run in this environment because Gradle is not installed and the Gradle distribution could not be downloaded here. Do not treat this package as a verified/compiled build.
- Start testing with Java 21. Runtime 25 may work, but should be tested separately.
- Use modules only where permitted by the world/server rules. This project does not bypass anti-cheat or server restrictions.
