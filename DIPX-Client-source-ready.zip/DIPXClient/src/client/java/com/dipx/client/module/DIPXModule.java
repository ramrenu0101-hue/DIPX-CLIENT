package com.dipx.client.module;

public final class DIPXModule {
    private final String name, description;
    private final ModuleCategory category;
    private boolean enabled;
    public DIPXModule(String name, String description, ModuleCategory category) {
        this.name = name; this.description = description; this.category = category;
    }
    public String name() { return name; }
    public String description() { return description; }
    public ModuleCategory category() { return category; }
    public boolean enabled() { return enabled; }
    public void toggle() { enabled = !enabled; }
    public void setEnabled(boolean value) { enabled = value; }
}
