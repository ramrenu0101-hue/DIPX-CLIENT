package com.dipx.client.module;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class ModuleRegistry {
    private static final List<DIPXModule> MODULES = new ArrayList<>();
    private static boolean registered;
    private ModuleRegistry() {}
    private static void add(String n, String d, ModuleCategory c) { MODULES.add(new DIPXModule(n,d,c)); }
    public static void registerDefaults() {
        if (registered) return; registered = true;
        add("Crystal Damage HUD", "Estimate and display crystal damage information", ModuleCategory.CRYSTAL_PVP);
        add("Surround Inspector", "Visualize nearby obsidian surround blocks", ModuleCategory.CRYSTAL_PVP);
        add("Totem Counter", "Track your visible totem count", ModuleCategory.CRYSTAL_PVP);
        add("Safe Anchor Preview", "Preview anchor charge state and self-risk indicators", ModuleCategory.ANCHOR_PVP);
        add("Anchor Threat Alert", "Warn when nearby respawn anchors are primed", ModuleCategory.ANCHOR_PVP);
        add("Mace Smash HUD", "Show fall distance and smash timing information", ModuleCategory.MACE_PVP);
        add("Wind Charge Counter", "Track available wind charges", ModuleCategory.MACE_PVP);
        add("Target Info HUD", "Display information about the entity you are looking at", ModuleCategory.COMBAT);
        add("Combo Tracker", "Track consecutive hits locally", ModuleCategory.COMBAT);
        add("Aim Trainer", "Local aim-practice overlay for private worlds", ModuleCategory.COMBAT);
        add("Toggle Sprint", "Remember sprint preference", ModuleCategory.MOVEMENT);
        add("Safe Walk", "Client-side edge sneak assistance", ModuleCategory.MOVEMENT);
        add("FullBright", "Improve visibility in dark areas", ModuleCategory.RENDER);
        add("Entity Tracers", "Visual entity direction indicators", ModuleCategory.RENDER);
        add("Coordinates HUD", "Display current coordinates", ModuleCategory.PLAYER);
        add("Armor HUD", "Display equipped armor and durability", ModuleCategory.PLAYER);
        add("Potion HUD", "Display active status effects", ModuleCategory.PLAYER);
        add("Chunk Borders", "Show chunk boundary information", ModuleCategory.WORLD);
        add("Waypoint List", "Manage personal world waypoints", ModuleCategory.WORLD);
        add("Friend List", "Mark trusted players in the local UI", ModuleCategory.MISC);
        add("Notifications", "Show DIPX module notifications", ModuleCategory.MISC);
        add("Inventory Search", "Search visible inventory item names", ModuleCategory.INVENTORY);
        add("Quick Move Helper", "Inventory organization helper", ModuleCategory.INVENTORY);
        add("DIPX Guardian", "Local warnings for nearby threats", ModuleCategory.EXCLUSIVE);
        add("DIPX Predict", "Damage and fall information overlays", ModuleCategory.EXCLUSIVE);
        add("DIPX Clutch HUD", "Survival resource status at a glance", ModuleCategory.EXCLUSIVE);
        add("DIPX Radar", "Nearby entity awareness display", ModuleCategory.EXCLUSIVE);
        add("DIPX Smart Switch", "Suggest a suitable held item for the current block", ModuleCategory.EXCLUSIVE);
        add("DIPX Overdrive", "Performance diagnostics and visual settings", ModuleCategory.EXCLUSIVE);
    }
    public static List<DIPXModule> all() { return Collections.unmodifiableList(MODULES); }
    public static long enabledCount() { return MODULES.stream().filter(DIPXModule::enabled).count(); }
}
