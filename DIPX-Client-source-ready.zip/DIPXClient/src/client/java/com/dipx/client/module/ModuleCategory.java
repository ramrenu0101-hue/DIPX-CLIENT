package com.dipx.client.module;

public enum ModuleCategory {
    CRYSTAL_PVP("Crystal PvP"), ANCHOR_PVP("Anchor PvP"), MACE_PVP("Mace PvP"),
    COMBAT("Combat"), MOVEMENT("Movement"), RENDER("Render"), PLAYER("Player"),
    WORLD("World"), MISC("Misc"), INVENTORY("Inventory"), EXCLUSIVE("DIPX Exclusive");
    public final String title;
    ModuleCategory(String title) { this.title = title; }
}
