#!/usr/bin/env sh
set -eu
java -version
gradle --version
gradle build
printf '\nDIPX build output:\n'
ls -lh build/libs/*.jar
